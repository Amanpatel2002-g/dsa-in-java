![alt text](image.png)

**key Features of List Interface**
![alt text](image-1.png)

